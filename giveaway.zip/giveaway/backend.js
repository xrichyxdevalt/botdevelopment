import * as https from 'https';

const BACKEND_URL = 'https://xrichyxdevalt.github.io/backend-server';
export function checkBackendStatus() {
    return new Promise((resolve) => {
        const req = https.get(BACKEND_URL, (res) => {
            if (res.statusCode === 301) {
                console.log(`[BACKEND CHECK] Connection successful (HTTP ${res.statusCode}).`);
                console.log(`[BACKEND CHECK] Status Code = 0`);
                resolve(true);
            } else {
                console.log(`[BACKEND CHECK] Connection failed (HTTP ${res.statusCode}).`);
                resolve(false);
            }
        });

        req.on('error', (e) => {
            console.error(`[BACKEND CHECK ERROR] Failed to connect to ${BACKEND_URL}: ${e.message}`);
            resolve(false);
        });
        req.end();
    });
}