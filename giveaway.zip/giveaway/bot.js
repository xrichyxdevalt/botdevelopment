import { Client, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType } from 'discord.js';
import * as fs from 'fs';
import * as readline from 'readline';
import * as path from 'path';
import { setBotStatus } from './status.js';
import { checkBackendStatus } from './backend.js';

const TOKEN = 'your-discord-bot-token-here';
const GIVEAWAY_EMOJI = '🎉';
const DATA_FILE = path.join(process.cwd(), 'giveaways.json');
const ADMIN_FILE = path.join(process.cwd(), 'admins.json');
const BOT_OWNER_ID = 'your-userid-here'; // to get enable developer mode on discord
const GUILD_ID = 'your-serverid-here'; // to get enable developer mode on discord
const BOT_AUTHOR = '.xrichyx';

let daBot = null;
let isRunning = false;
let giveaways = [];
let botAdmins = [BOT_OWNER_ID];
let startTime = null;
let intervalId = null;

function loadData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = fs.readFileSync(DATA_FILE, 'utf8');
            giveaways = JSON.parse(data);
            console.log(`[DATA] Loaded ${giveaways.length} saved giveaways!`);
        }
    } catch (e) {
        console.error("[DATA ERROR] Couldn't load giveaways:", e.message);
    }
    try {
        if (fs.existsSync(ADMIN_FILE)) {
            const data = fs.readFileSync(ADMIN_FILE, 'utf8');
            botAdmins = JSON.parse(data).admins || [BOT_OWNER_ID];
            if (!botAdmins.includes(BOT_OWNER_ID)) botAdmins.push(BOT_OWNER_ID);
            console.log(`[DATA] Loaded ${botAdmins.length} bot admins.`);
        }
    } catch (e) {
        console.error("[DATA ERROR] Couldn't load admins:", e.message);
    }
}
function saveData() {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(giveaways, null, 2));
        fs.writeFileSync(ADMIN_FILE, JSON.stringify({ admins: botAdmins }, null, 2));
    } catch (e) {
        console.error("[DATA ERROR] FAILED TO SAVE DATA!!!", e.message);
    }
}
function msToDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const m = Math.floor(seconds / (3600 * 24 * 30.4375 * 12));
    const yr = Math.floor(seconds / (3600 * 24 * 30.4375));
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const min = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    const parts = [];
    if (m > 0) parts.push(`${m} month${m !== 1 ? 's' : ''}`);
    if (d > 0) parts.push(`${d % 30} day${d !== 1 ? 's' : ''}`);
    if (h > 0) parts.push(`${h} hour${h !== 1 ? 's' : ''}`);
    if (min > 0) parts.push(`${min} minute${min !== 1 ? 's' : ''}`);
    if (s > 0) parts.push(`${s} second${s !== 1 ? 's' : ''}`);
    return parts.length > 0 ? parts.join(', ') : 'just a sec!';
}

function isAdmin(userId) {
    return botAdmins.includes(userId);
}

async function finishGiveaway(g) {
    if (!daBot) return;
    console.log(`[GIVEAWAY] Ending giveaway in channel ${g.channelId}`);
    const channel = await daBot.channels.fetch(g.channelId).catch(() => null);
    if (!channel) return console.error(`[GIVEAWAY ERROR] Channel not found for ${g.messageId}`);
    const message = await channel.messages.fetch(g.messageId).catch(() => null);
    if (!message) return console.error(`[GIVEAWAY ERROR] Message not found for ${g.messageId}`);
    let users = [];
    try {
        const reaction = message.reactions.cache.get(GIVEAWAY_EMOJI);
        if (reaction) {
            const fetchedUsers = await reaction.users.fetch();
            users = fetchedUsers.filter(user => !user.bot).map(user => user.id);
        }
    } catch (error) {
        console.error('[GIVEAWAY ERROR] Failed to fetch reactions:', error.message);
    }
    let winners = [];
    if (users.length > 0) {
        for (let i = users.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [users[i], users[j]] = [users[j], users[i]];
        }
        winners = users.slice(0, g.winners);
    }
    const endEmbed = new EmbedBuilder()
        .setTitle(`[ENDED] ${g.prize}`)
        .setDescription(`**Prize:** ${g.prize}\n**Winners:** ${g.winners}\n**Hosted by:** <@${g.hostedBy}>`)
        .setColor(0xFF0000);
    if (winners.length > 0) {
        const winnerMentions = winners.map(id => `<@${id}>`).join(', ');
        endEmbed.addFields({ name: `${GIVEAWAY_EMOJI} Winners! ${GIVEAWAY_EMOJI}`, value: winnerMentions, inline: false });
        await channel.send({ content: `CONGRATS!!! ${winnerMentions} won **${g.prize}**! You better claim it fast.` });
    } else {
        endEmbed.addFields({ name: 'No Winners :(', value: 'Not enough people joined, sorry!' });
    }

    await message.edit({ embeds: [endEmbed], components: [] }).catch(console.error);
    giveaways = giveaways.filter(item => item.messageId !== g.messageId);
    saveData();
}

function startGiveawayChecker() {
    if (intervalId) clearInterval(intervalId);
    intervalId = setInterval(() => {
        const now = Date.now();
        const finishedGiveaways = giveaways.filter(g => g.endTime <= now);
        finishedGiveaways.forEach(g => {
            finishGiveaway(g);
        });
    }, 5000);
}

async function handleCreateCommand(interaction) {
    if (!interaction.memberPermissions.has('ManageGuild')) {
        return interaction.reply({ content: "LOL, you need to be an admin on this server to start giveaways. Get lost.", ephemeral: true });
    }
    const prize = interaction.options.getString('prize');
    const timeString = interaction.options.getString('time');
    const winnerCount = interaction.options.getInteger('winners');
    const timeMatch = timeString.match(/^(\d+)([dhm])$/);
    if (!timeMatch) {
        return interaction.reply({ content: "That time format is wrong! Try something like `1h`, `30m`, or `5d`.", ephemeral: true });
    }
    const durationValue = parseInt(timeMatch[1]);
    const durationUnit = timeMatch[2];
    let durationMs = 0;
    switch (durationUnit) {
        case 'd':
            durationMs = durationValue * 24 * 60 * 60 * 1000;
            break;
        case 'h':
            durationMs = durationValue * 60 * 60 * 1000;
            break;
        case 'm':
            durationMs = durationValue * 60 * 1000;
            break;
    }
    if (durationMs < 60000) {
        return interaction.reply({ content: "The giveaway has to be at least 1 minute long! Chill out.", ephemeral: true });
    }
    const endTime = Date.now() + durationMs;
    const hostedBy = interaction.user.id;
    const readableTime = msToDuration(durationMs);
    const giveawayEmbed = new EmbedBuilder()
        .setTitle(`🎉 GIVEAWAY: ${prize} 🎉`)
        .setDescription(
            `React with ${GIVEAWAY_EMOJI} to enter!\n\n` +
            `**Time Left:** ${readableTime} (Ends <t:${Math.floor(endTime / 1000)}:R>)\n` +
            `**Winners:** ${winnerCount} lucky person${winnerCount !== 1 ? 's' : ''}\n` +
            `**Hosted by:** <@${hostedBy}>`
        )
        .setColor(0x00FF00)
        .setTimestamp(endTime);
    await interaction.reply({ content: `I'm starting a new giveaway right now!`, ephemeral: true });
    const giveawayMessage = await interaction.channel.send({ embeds: [giveawayEmbed] });
    await giveawayMessage.react(GIVEAWAY_EMOJI);
    const newGiveaway = {
        messageId: giveawayMessage.id,
        channelId: giveawayMessage.channelId,
        endTime: endTime,
        prize: prize,
        winners: winnerCount,
        hostedBy: hostedBy
    };
    giveaways.push(newGiveaway);
    saveData();
}

async function handleEndCommand(interaction) {
    if (!interaction.memberPermissions.has('ManageGuild')) {
        return interaction.reply({ content: "LOL, you need to be an admin on this server to end giveaways. Get lost.", ephemeral: true });
    }
    const messageId = interaction.options.getString('messageid');
    const giveawayToFind = giveaways.find(g => g.messageId === messageId && g.channelId === interaction.channelId);
    if (!giveawayToFind) {
        return interaction.reply({ content: "I can't find an active giveaway with that ID in this channel, are you sure?", ephemeral: true });
    }
    giveawayToFind.endTime = Date.now();
    saveData();
    await interaction.reply({ content: `Okay, I forced the giveaway with ID **${messageId}** to end right now. Checking the winner in a sec!`, ephemeral: true });
}

async function handleRerollCommand(interaction) {
    if (!interaction.memberPermissions.has('ManageGuild')) {
        return interaction.reply({ content: "LOL, you need to be an admin on this server to reroll winners. Get lost.", ephemeral: true });
    }
    const messageId = interaction.options.getString('messageid');
    const channel = interaction.channel;
    const message = await channel.messages.fetch(messageId).catch(() => null);
    if (!message) {
        return interaction.reply({ content: "Can't find that message ID in this channel, sorry!", ephemeral: true });
    }
    const oldEmbed = message.embeds[0];
    if (!oldEmbed || !oldEmbed.title || !oldEmbed.title.startsWith('[ENDED]')) {
        return interaction.reply({ content: "That message doesn't look like an ended giveaway embed. Maybe it's still running?", ephemeral: true });
    }
    const prize = oldEmbed.title.replace('[ENDED] ', '');
    const winnerCountMatch = oldEmbed.description.match(/Winners:\s*(\d+)/);
    const winnerCount = winnerCountMatch ? parseInt(winnerCountMatch[1]) : 1;
    let users = [];
    try {
        const reaction = message.reactions.cache.get(GIVEAWAY_EMOJI);
        if (reaction) {
            const fetchedUsers = await reaction.users.fetch();
            users = fetchedUsers.filter(user => !user.bot).map(user => user.id);
        }
    } catch (error) {
        console.error('[GIVEAWAY ERROR] Failed to fetch reactions for reroll:', error.message);
    }
    let winners = [];
    if (users.length > 0) {
        for (let i = users.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [users[i], users[j]] = [users[j], users[i]];
        }
        winners = users.slice(0, winnerCount);
    }
    if (winners.length > 0) {
        const winnerMentions = winners.map(id => `<@${id}>`).join(', ');
        await interaction.reply({ content: `**REROLL!** The new winner(s) for **${prize}** is/are: ${winnerMentions}! Good job.`, ephemeral: false });
    } else {
        await interaction.reply({ content: `Nobody won the reroll, still not enough entries.`, ephemeral: false });
    }
}

async function handleAdminAddCommand(interaction) {
    if (!isAdmin(interaction.user.id)) {
        return interaction.reply({ content: "You're not cool enough to use this command. Only bot admins can.", ephemeral: true });
    }
    const user = interaction.options.getUser('user');
    if (botAdmins.includes(user.id)) {
        return interaction.reply({ content: `<@${user.id}> is already a bot admin, duh.`, ephemeral: true });
    }
    botAdmins.push(user.id);
    saveData();
    await interaction.reply({ content: `Okay, <@${user.id}> is now a bot admin! They can now use admin commands everywhere.`, ephemeral: false });
}

async function handleAdminRemoveCommand(interaction) {
    if (!isAdmin(interaction.user.id)) {
        return interaction.reply({ content: "You're not cool enough to use this command. Only bot admins can.", ephemeral: true });
    }
    const user = interaction.options.getUser('user');
    if (user.id === BOT_OWNER_ID) {
        return interaction.reply({ content: "You can't remove the main owner, that's not allowed!", ephemeral: true });
    }
    const initialLength = botAdmins.length;
    botAdmins = botAdmins.filter(id => id !== user.id);
    if (botAdmins.length === initialLength) {
        return interaction.reply({ content: `<@${user.id}> wasn't a bot admin anyway, chill.`, ephemeral: true });
    }
    saveData();
    await interaction.reply({ content: `RIP. <@${user.id}> is no longer a bot admin.`, ephemeral: false });
}


const commands = [
    {
        name: 'gcreate',
        description: 'Starts a brand new giveaway!',
        options: [
            {
                name: 'prize',
                description: 'What the winner gets!',
                type: ApplicationCommandOptionType.String,
                required: true,
            },
            {
                name: 'time',
                description: 'How long the giveaway lasts (e.g., 1h, 30m, 5d)',
                type: ApplicationCommandOptionType.String,
                required: true,
            },
            {
                name: 'winners',
                description: 'How many winners there will be.',
                type: ApplicationCommandOptionType.Integer,
                required: true,
                minValue: 1
            },
        ],
    },
    {
        name: 'gend',
        description: 'Ends an active giveaway right now and picks a winner.',
        options: [
            {
                name: 'messageid',
                description: 'The message ID of the giveaway.',
                type: ApplicationCommandOptionType.String,
                required: true,
            },
        ],
    },
    {
        name: 'greroll',
        description: 'Picks a new winner for a giveaway that already ended.',
        options: [
            {
                name: 'messageid',
                description: 'The message ID of the ended giveaway.',
                type: ApplicationCommandOptionType.String,
                required: true,
            },
        ],
    },
    {
        name: 'gadminadd',
        description: 'Adds a user as a bot admin (can use admin commands on any server).',
        options: [
            {
                name: 'user',
                description: 'The user to make a bot admin.',
                type: ApplicationCommandOptionType.User,
                required: true,
            },
        ],
    },
    {
        name: 'gadminremove',
        description: 'Removes a user from being a bot admin.',
        options: [
            {
                name: 'user',
                description: 'The user to remove as a bot admin.',
                type: ApplicationCommandOptionType.User,
                required: true,
            },
        ],
    },
];

async function deployCommands() {
    if (!daBot) return;
    try {
        console.log('[BOT] Deploying slash commands globally...');
        const guild = await daBot.guilds.fetch(GUILD_ID).catch(() => null);
        if (guild) {
            await guild.commands.set(commands);
            console.log(`[BOT] Deployed commands to guild ${GUILD_ID}!`);
        } else {
            await daBot.application.commands.set(commands);
            console.log('[BOT] Deployed commands globally (might take a while to show up everywhere).');
        }
    } catch (e) {
        console.error('[COMMANDS ERROR] Failed to deploy commands:', e.message);
    }
}


async function startBot() {
    if (isRunning) {
        console.log('[CONSOLE] Bot is already running, dude!');
        return;
    }
    loadData();
    daBot = new Client({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
        ],
        partials: [Partials.Message, Partials.Channel, Partials.Reaction],
    });
    daBot.on('ready', async () => {
        console.log(`[DISCORD] Logged in as ${daBot.user.tag}! WOO HOO!`);
        console.log('[INFO] Started Giveaway Bot V1.0');
        console.log(`[INFO] Giveaway Bot ready.`);
        startTime = Date.now();
        isRunning = true;
        await deployCommands();
        startGiveawayChecker();
        setBotStatus(daBot, '.xrichys testing bot'); // edit this to change the status people
    });
    daBot.on('interactionCreate', async interaction => {
        if (!interaction.isCommand()) return;
        console.log(`[COMMAND] ${interaction.user.tag} used /${interaction.commandName}`);
        switch (interaction.commandName) {
            case 'gcreate':
                handleCreateCommand(interaction);
                break;
            case 'gend':
                handleEndCommand(interaction);
                break;
            case 'greroll':
                handleRerollCommand(interaction);
                break;
            case 'gadminadd':
                handleAdminAddCommand(interaction);
                break;
            case 'gadminremove':
                handleAdminRemoveCommand(interaction);
                break;
            default:
                interaction.reply({ content: 'Idk that command...', ephemeral: true });
        }
    });
    try {
        await daBot.login(TOKEN);
    } catch (e) {
        console.error(`[CRITICAL] Error logging in: ${e.message}`);
        isRunning = false;
        daBot = null;
    }
}

function stopBot() {
    if (!isRunning) {
        console.log('[CONSOLE] Bot is already off, what are you doing?');
        return;
    }
    if (intervalId) clearInterval(intervalId);
    daBot.destroy();
    isRunning = false;
    daBot = null;
    console.log('[CONSOLE] Bot has been STOPPED successfully.');
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: false
});
console.log('--- Giveaway Bot Console ---');
console.log('Type "help" to see all available console commands.');
console.log('----------------------------');
rl.on('line', (line) => {
    const command = line.trim().toLowerCase();
    switch (command) {
        case 'start':
            startBot();
            break;
        case 'stop':
            stopBot();
            break;
        case 'uptime':
            if (isRunning && startTime) {
                const duration = Date.now() - startTime;
                console.log(`[CONSOLE] I've been running for: ${msToDuration(duration)}`);
            } else {
                console.log('[CONSOLE] The bot is not running right now.');
            }
            break;
        case 'author':
            console.log(`[CONSOLE] This bot was made by ${BOT_AUTHOR}.`);
            break;
        case 'help':
            console.log('\n--- Console Commands ---');
            console.log('start     - Starts the Discord bot.');
            console.log('stop      - Stops the Discord bot.');
            console.log('uptime    - Shows how long the bot has been running.');
            console.log('author    - Displays the bot creator\'s name.');
            console.log('help      - Shows this list of commands.');
            console.log('------------------------\n');
            break;
        default:
            console.log(`[CONSOLE] Unknown command: ${command}. Type 'help' for a list of commands.`);
    }
});

async function main() {
    console.log('[INIT] Checking backend status...');
    const canStart = await checkBackendStatus();

    if (canStart) {
        console.log('[INIT] Backend check passed. Starting bot...');
        startBot();
    } else {
        console.log('[CRITICAL] Backend check failed. Bot will NOT start.');
    }
}

main();