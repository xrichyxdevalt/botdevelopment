import { ActivityType } from 'discord.js';

export function setBotStatus(client, statusText) {
    if (client.user) {
        client.user.setActivity(statusText, { type: ActivityType.Playing });
        console.log(`[STATUS] Set bot activity to: 'Playing ${statusText}'`);
    } else {
        console.error('[STATUS ERROR] Cannot set status: Client user is not available.');
    }
}